var count;
$(document).ready(function(){    
    count = $(".config-bars").length;
    console.log(count);
    fnOpenUserDetailedPage("btn-0", "", "contenttab0");
});
function fnOpenUserDetailedPage(targetUserID, evt, cityName){      
    var selectedUserID = $("#"+targetUserID).attr("data-tab-title");    
    var userId = targetUserID.split("-");    
    var tabselector = 'contenttab'+userId[1];
    
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("contenttab");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";            
    }
    tablinks = document.getElementsByClassName("config-bars");
    var resttabs= (tablinks.length - (userId[1] + 1));
    console.log("selected tab index :: "+userId[1]);
    console.log("Rest of the tabs ::" + resttabs);
    for (i = userId[1]; i <tablinks.length; i++) { 
      console.log("Index :: " + i);       
      tablinks[i].style.backgroundColor = "rgba(70, 130, 180)";     
    }    
    $("#"+cityName).css('display', 'block'); 
    $("#"+cityName).css('height', '100%');   
    $("#"+targetUserID).css('background-color','green');
    $('h3').text(selectedUserID);  
}

