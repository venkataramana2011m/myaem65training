## [1.5.0] - 2022-12-22
### Updates
- update to Angular 14
- update all dependencies to match Angular 14 version


## [1.4.0] - 2020-12-14
### Updates
- update to Angular 11
- update all dependencies to match Angular 11 version

## [1.3.0] - 2020-03-17
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.2.0] - 2019-01-09
### Updates
- updated Angular to latest version(Angular 7)
- updated Bootstrap to 4.1.2
- updated all dependencies to fix the warnings
- fixed error with responsive menu
- fixed design errors for datepicker + tooltips


## [1.1.0] - 2018-08-21
### Updates
- updated Angular to latest version
- updated Bootstrap to 4.1.0
- updated ng-bootstrap to 2.0.0
- updated all dependencies to fix the warnings

## [1.0.1] - 2018-05-23
### Fixes
- changed some links

## [1.0.0] - 2017-05-10
### initial Release
