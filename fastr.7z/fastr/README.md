fastr
==

A Quicker solution for browsing movies and TV shows!

![screenshot](https://raw.github.com/jonnyhsy/fastr/master/Fastr-Movie-Browser.png)

Code from SitePoint article "Making API Calls in AngularJS using Angular's $http service"

Article URL: http://www.sitepoint.com/api-calls-angularjs-http-service

### License ###

[MIT License (MIT)](https://github.com/tanay1337/fastr/blob/master/LICENSE)
