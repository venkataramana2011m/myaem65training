'use strict';

var App = function() {
    var element = document.getElementById("hello-world");
    element.innerHTML="Successfully loaded the application";
};

module.exports = App;
