var ExampleClassTest = TestCase("ExampleClassTest");

ExampleClassTest.prototype.testSomething = function()
{
	assertEquals(1, 1);
};
