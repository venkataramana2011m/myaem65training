package com.myaem65training.core.service;

public interface Fetchuserservice {

	
}
