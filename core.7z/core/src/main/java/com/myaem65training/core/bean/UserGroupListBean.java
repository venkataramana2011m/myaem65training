package com.myaem65training.core.bean;

public class UserGroupListBean {
	
	private String group;

	private String researchCompletedDate;

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getResearchCompletedDate() {
		return researchCompletedDate;
	}

	public void setResearchCompletedDate(String researchCompletedDate) {
		this.researchCompletedDate = researchCompletedDate;
	}
}
