package com.myaem65training.core.service.impl;

import com.myaem65training.core.service.Fetchuserservice;

public class Fetchuserserviceimpl {

}
