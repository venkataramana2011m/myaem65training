package com.myaem65training.core.models;

import java.util.List;
import java.util.Map;

public interface CardsCarouselWithMap {
    String getCardsCarouselListingTitle();
    List<Map<String,String>> getCardDetailsWithMap();
}
