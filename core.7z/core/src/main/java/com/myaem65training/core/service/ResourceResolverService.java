package com.myaem65training.core.service;

import org.apache.sling.api.resource.ResourceResolver;

public interface ResourceResolverService {
    ResourceResolver getResourceResolver();
}