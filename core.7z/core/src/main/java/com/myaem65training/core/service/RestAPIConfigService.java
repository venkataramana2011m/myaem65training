package com.myaem65training.core.service;

public interface RestAPIConfigService {
	
	public String getRestfulAPIPathConfig();
	
	public String getRestfulAPIKeyConfig();
	
	public String getRestfulAPIHostConfig();
}
