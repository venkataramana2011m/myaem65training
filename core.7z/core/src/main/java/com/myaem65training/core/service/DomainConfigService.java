package com.myaem65training.core.service;

public interface DomainConfigService {
	
	public String getDomainPathConfig();
	
	public boolean getEnableConfig();

}
