package com.myaem65training.core.service;

public interface MyNYTimesAPIConfigService {
    public String getNYTimesAPIConfigEndPoint();

    public String getNYTimesAPIConfigApiID();

    public String getNYTimesAPIConfigApiKey();

    public String getNYTimesAPIConfigSecretKey();

    public String getNYTimesAPIConfigBooksListEndPoint();

    public String getNYTimesAPIConfigBooksListByCategoryEndPoint();
}
