$(document).ready(function() {
    
});
function fnshowImg(trgtsrc){ document.getElementById("featured-image").src = trgtsrc; }

